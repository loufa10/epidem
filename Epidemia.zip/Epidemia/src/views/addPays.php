<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pays Registration</title>
    <link rel="stylesheet" href="style.css">
    <style>
   /* Set a style for all buttons */
   input[type=submit] {
    background-color:#518ab0;
    color: white;
    padding: 4px 2px;
    margin: 8px 0;
    border: none;
    border: none;
    border-radius: 80px;
    cursor: pointer;
    width: 10%;
   }
   input[type=reset] {
    background-color:#518ab0;
    color: white;
    padding: 4px 0px;
    margin: 8px 0;
    border: none;
    border-radius: 80px;
    cursor: pointer;
    width: 10%;
   }
   input[type=submit]:hover {
    background-color: white;
    color: #af5370;
    border: 1px solid #518ab0;
    border: none;
    border-radius: 80px;
   }
   input[type=reset]:hover {
    background-color: white;
    color: #af5370;
    border: 1px solid #518ab0;
    border: none;
    border-radius: 80px;
   }
   
 </style>
</head>
<body>

    <form  action="http://localhost:8080/Epidemia/src/controller/PaysController.php" method="post">
        <center>
            <div>
            <label for="">Nom Pays : </label>
            <input type="text" id="nom" name="nom"/>
        </div>
        <br>
        <div>
            <label for="">PopulationTotal : </label>
            <input type="text" name="population" />
        </div>
        <br>
        <div>
            <label for="">listeZone : </label>
            <input type="text" id= "listeZone"name="listezone"/>
        </div>
        <br>
        <div>
            <input type="submit" name="submit" value="Envoyer"/>
            <input type="reset" name="reset" value="Annuler"/>
        </div>
        </center>
    </form>
</body>
</html>