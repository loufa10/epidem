<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table>
        <tr>
            <th>ID  :</th>
            <th>Nom  :</th>
            <th>Prenom :</th>
            <th>Numero telephone :</th>
            <th>Adresse :</th>
            <th>Sexe :</th>
            <th>Résultat :</th>
         
        </tr>
        <?php 
            include_once "../repository/Fonction.php";

            $edb = new Fonction();

            $Personne = $edb->GetAllPersonne();

            foreach ($Personne as $personne) 
            {
                echo "<tr>
                        <td>$personne[0]</td>
                        <td>$personne[1]</td>
                        <td>$personne[2]</td>
                        <td>$personne[3]</td>
                        <td>$personne[4]</td>
                        <td>$personne[5]</td>
                        <td>$personne[6]</td>
                        
                    </tr>";
            }
        ?>
    </table>
</body>
</html>