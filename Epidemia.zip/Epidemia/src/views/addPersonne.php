<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
   /* Style the form container */
form {
  max-width: 500px;
  margin: 0 auto;
  padding: 20px;
  background-color: #f8f8f8;
  border-radius: 5px;
}

/* Style the input labels */
label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
}

/* Style the input fields */
input[type="text"],
input[type="number"],
select {
  width: 100%;
  padding: 10px;
  margin-bottom: 20px;
  border: none;
  border-radius: 5px;
  background-color: #e9e9e9;
}

/* Style the select dropdown arrow */
select {
  background-image: url("https://cdn4.iconfinder.com/data/icons/ionicons/512/icon-ios7-arrow-down-512.png");
  background-repeat: no-repeat;
  background-position: right 10px center;
  appearance: none;
  -webkit-appearance: none;
  -moz-appearance: none;
}

/* Style the submit and reset buttons */
input[type="submit"],
input[type="reset"] {
  display: inline-block;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  background-color: #518ab0;
  color: #fff;
  font-size: 16px;
  cursor: pointer;
}

/* Style the submit and reset button on hover */
input[type="submit"]:hover,
input[type="reset"]:hover {
  background-color: #af5370;
}
 </style>
</head>
<body>
    <form action="http://localhost/Epidemia/src/controller/PersonneController.php" method="post">
        <center>
        <div>
            <label for="">Nom : </label>
            <input type="text" name="nomP"/>
        </div>
        <br>
        <div>
            <label for="">Prenom : </label>
            <input type="text" name="prenomP" />
           
        </div>
        <br>
        <div>
            <label for="">Numero de telephone : </label>
            <input type="number" name="numTel"/>
        </div>
        <br>
        <div>
            <label for="">Adresse : </label>
            <input type="text" name="adresse" />
        </div>
        <br>
        <div>
            <label for="">Sexe : </label>
            <!-- <input type="text" name="sexe" /> -->
            <select name="sexe"> 
                <option value="homme"> Homme </option>
                <option value="femme"> Femme</option>
                
            </select>
        </div>
        <br>
        <div>
            <label for="">Résultat: </label>
            <select name="résultat"> 
                <option value="positive"> positive </option>
                <option value="négative"> négative</option>
                <option value="symptômatique">symptômatique</option>
            </select>
        </div>
        <br>
        <div>
            <input type="submit" name="submit" value="Envoyer"/>
            <input type="reset" name="reset" value="Annuler"/>
        </div>
        </center>
    </form>
</body>
</html>