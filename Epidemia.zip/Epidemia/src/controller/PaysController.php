<?php

include_once "../entities/Pays.php";
include_once "../repository/DB.php";
include_once "../repository/Fonction.php";


if(isset($_POST['submit']))
{
    extract($_POST);

    $pays = new Pays;

    $pays->setNomPays($_POST['nom']);
    $pays->setPopulationTotal($_POST['population']);
    $pays->setListeZone($_POST['listezone']);
 
    $sdb = new Fonction();

    $sdb->insertPays($pays);

    header("location:http://localhost:8080/Epidemia/src/views/showPays.php");

}